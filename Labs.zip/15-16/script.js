class GuessNumberGame {
    constructor(maxNumber) {
        this.maxNumber = maxNumber;
        this.restart(); // Начать игру сразу
    }

    // Рестарт игры
    restart() {
        this.secretNumber = Math.floor(Math.random() * this.maxNumber) + 1;
        this.attempts = 0;
        this.isGameOver = false;
        this.updateUI("Игра началась! Угадайте число от 1 до " + this.maxNumber + ".");
    }

    // Обработка попытки
    guess(number) {
        if (this.isGameOver) {
            return "Игра окончена. Нажмите 'Сыграть снова'.";
        }

        this.attempts++;
        if (number === this.secretNumber) {
            this.isGameOver = true;
            return `Правильно! Ты угадал за ${this.attempts} попыток.`;
        } else if (number > this.secretNumber) {
            return "Слишком большое!";
        } else {
            return "Слишком маленькое!";
        }
    }

    // Обновление интерфейса
    updateUI(message) {
        document.getElementById("message").textContent = message;
        document.getElementById("attempts").textContent = `Попыток: ${this.attempts}`;
    }
}

// Создаём экземпляр игры
const game = new GuessNumberGame(100);

// Связываем события с элементами
document.getElementById("submit-btn").addEventListener("click", () => {
    const input = document.getElementById("guess-input");
    const guess = parseInt(input.value, 10);

    if (isNaN(guess) || guess < 1 || guess > game.maxNumber) {
        game.updateUI("Пожалуйста, введите число от 1 до 100.");
        return;
    }

    const result = game.guess(guess);
    game.updateUI(result);

    // Показываем кнопку рестарта, если игра закончена
    if (game.isGameOver) {
        document.getElementById("restart-btn").style.display = "block";
        document.getElementById("submit-btn").style.display = "none";
    }

    // Очищаем поле ввода
    input.value = "";
});

document.getElementById("restart-btn").addEventListener("click", () => {
    game.restart();
    document.getElementById("restart-btn").style.display = "none";
    document.getElementById("submit-btn").style.display = "inline-block";
});
