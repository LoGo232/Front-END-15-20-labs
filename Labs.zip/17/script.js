// 1. События мыши
document.getElementById("mouse-btn").addEventListener("click", () => {
    document.getElementById("mouse-result").textContent = "Кнопка нажата!";
});

// 2. События клавиатуры
document.getElementById("keyboard-input").addEventListener("keydown", (event) => {
    document.getElementById("keyboard-result").textContent = `Вы нажали: ${event.key}`;
});

// 3. Drag & Drop
const dragItem = document.getElementById("drag-item");
const dropZone = document.getElementById("drop-zone");

dragItem.addEventListener("dragstart", () => {
    dragItem.textContent = "Перетаскиваю!";
});
dropZone.addEventListener("dragover", (event) => {
    event.preventDefault();
    dropZone.style.borderColor = "green";
});
dropZone.addEventListener("drop", () => {
    dropZone.textContent = "Элемент сброшен!";
});

// 4. События указателя
const pointerBox = document.getElementById("pointer-box");
pointerBox.addEventListener("pointermove", (event) => {
    document.getElementById("pointer-result").textContent = `Координаты указателя: (${event.clientX}, ${event.clientY})`;
});

// 5. События полосы прокрутки
document.getElementById("scroll-box").addEventListener("scroll", () => {
    const scrollTop = document.getElementById("scroll-box").scrollTop;
    document.getElementById("scroll-result").textContent = `Смещение прокрутки: ${scrollTop}px`;
});

// 6. События сенсорных экранов
const touchBox = document.getElementById("touch-box");
touchBox.addEventListener("touchstart", () => {
    document.getElementById("touch-result").textContent = "Касание началось!";
});
touchBox.addEventListener("touchend", () => {
    document.getElementById("touch-result").textContent = "Касание завершено!";
});

// 7. События с таймером
let timer;
document.getElementById("timer-start").addEventListener("click", () => {
    let counter = 0;
    document.getElementById("timer-result").textContent = "Таймер запущен!";
    timer = setInterval(() => {
        counter++;
        document.getElementById("timer-result").textContent = `Прошло времени: ${counter} секунд`;
    }, 1000);
});

document.getElementById("timer-stop").addEventListener("click", () => {
    clearInterval(timer);
    document.getElementById("timer-result").textContent = "Таймер остановлен!";
});
