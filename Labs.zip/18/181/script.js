document.getElementById("submitButton").addEventListener("click", () => {
    // Получение данных из формы
    const name = document.getElementById("nameInput").value.trim();
    const age = document.getElementById("ageInput").value.trim();

    // Проверка выбора радиокнопок
    const gender = document.querySelector('input[name="gender"]:checked')?.value || "Не указан";

    // Сбор всех выбранных чекбоксов
    const interests = Array.from(document.querySelectorAll('input[name="interests"]:checked'))
        .map((checkbox) => checkbox.value);

    const country = document.getElementById("countrySelect").value;

    // Формирование результата
    const output = `
        <p><strong>Имя:</strong> ${name}</p>
        <p><strong>Возраст:</strong> ${age}</p>
        <p><strong>Пол:</strong> ${gender}</p>
        <p><strong>Интересы:</strong> ${interests.join(", ") || "Не указаны"}</p>
        <p><strong>Страна:</strong> ${country}</p>
    `;

    // Вывод данных на страницу
    document.getElementById("output").innerHTML = output;
});
