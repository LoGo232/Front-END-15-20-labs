const form = document.getElementById("validationForm");

form.addEventListener("submit", (event) => {
    event.preventDefault(); // Останавливаем отправку формы

    // HTML5 валидация
    if (!form.checkValidity()) {
        alert("Пожалуйста, заполните все обязательные поля корректно.");
        return;
    }

    // Дополнительная проверка через JS
    const name = document.getElementById("nameInput").value.trim();
    const email = document.getElementById("emailInput").value.trim();
    const password = document.getElementById("passwordInput").value.trim();

    if (password.length < 6) {
        alert("Пароль должен быть не менее 6 символов.");
        return;
    }

    // Проверка с регулярным выражением
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Введите корректный email.");
        return;
    }

    // Вывод результата
    document.getElementById("output").innerText = `Добро пожаловать, ${name}!`;
});
