document.getElementById("analyzeButton").addEventListener("click", () => {
    const inputText = document.getElementById("inputText").value.trim();
    const output = document.getElementById("output");
    output.innerHTML = ""; // Очищаем вывод

    // Пример 1: Использование флагов
    const regexGlobal = /\d+/g; // Поиск всех чисел
    const regexIgnoreCase = /привет/i; // Поиск "привет" без учета регистра

    output.innerHTML += `<p>Числа в тексте: ${inputText.match(regexGlobal)}</p>`;
    output.innerHTML += `<p>Содержит "привет" (без регистра): ${regexIgnoreCase.test(inputText)}</p>`;

    // Пример 2: Метод exec()
    const regexExec = /(\w+):(\d+)/g; // Шаблон "слово:число"
    let match;
    while ((match = regexExec.exec(inputText)) !== null) {
        output.innerHTML += `<p>Найдено: ключ = ${match[1]}, значение = ${match[2]}</p>`;
    }

    // Пример 3: Методы объекта String
    const regexReplace = /кошка/gi; // Замена "cat" на "dog" независимо от регистра
    const replacedText = inputText.replace(regexReplace, "собака");

    const regexSplit = /\s+/; // Разделение текста по пробелам
    const words = inputText.split(regexSplit);

    output.innerHTML += `<p>Текст после замены: ${replacedText}</p>`;
    output.innerHTML += `<p>Слова в тексте: ${words.join(", ")}</p>`;
});